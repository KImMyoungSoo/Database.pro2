var express = require('express');
var conn = require('./db');
var moment = require('moment')
var router = express.Router();

/* GET home page. */
router.post('/', function(req, res, next) {
    var select_sql = `select type from room where not exists(select * from (Select * from reservations where((checkin<=? and checkout>=?) or (checkin<=? and checkout>=?)or(checkin<=? and checkout>=?)or(checkin>=? and checkout<=?)))c where c.type=room.type);`
    var create_reserv = `INSERT INTO reservations (name, checkin, checkout, people, type, phone) VALUES (?,?,?,?,?,?);`

    var name = req.body.name;
    var people = req.body.people;
    var checkin = req.body.checkin;
    var checkout = req.body.checkout;
    var phone = req.body.phone;
    var roomtype = req.body.roomtype;
    
    var cin = new Date(checkin);
    var cout = new Date(checkout);

    console.log(name)
    console.log(people)
    console.log(cin)
    console.log(cout)

    conn.query(select_sql,[checkin,checkin,checkout,checkout,checkin,checkout,checkin,checkout], function(err,types){
        console.log(types[0].type);
        var count = 0;
        for(var i=0;i<types.length;i++){
            if(roomtype == types[i].type ){
                count = count + 1;
            }
        }
        if(count != 0){
            conn.query(create_reserv,[name,checkin,checkout,people,roomtype,phone], function(err2){
                console.log('here');
                if(err2){
                    console.log(err2);
                } else {
                    console.log('here');
                    res.redirect('/');
                }
            })
        } else {
            res.write("<script language=\"javascript\">alert('no room')</script>");
            res.write("<script language=\"javascript\">window.location=\"/\"</script>");
            console.log('out');
        }
    })
});

module.exports = router;