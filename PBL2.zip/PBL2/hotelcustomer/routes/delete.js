var express = require('express');
var conn = require('./db');
var router = express.Router();

//delete 
router.post('/', function(req,res,next){
    var del_id = req.body.del_id;
    console.log(del_id);
    var del_sql = `DELETE FROM reservations WHERE id=?;`
  
    conn.query(del_sql,[del_id], function(err){
      if(err){
        console.log(err);
      } else {
        res.redirect('/');
      }
    })
  })

module.exports = router;