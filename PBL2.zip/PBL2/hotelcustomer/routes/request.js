var express = require('express');
var conn = require('./db');
var router = express.Router();

//delete 
router.post('/', function(req,res,next){
    var room_number = req.body.room_number;
    var phone = req.body.phone;
    var comment = req.body.comment;

    var create_req = `INSERT INTO customer_request (room_number, phone, comment, check_ok) VALUES (?,?,?,0);`
  
    conn.query(create_req,[room_number,phone,comment], function(err){
        console.log('here');
        if(err){
            console.log(err);
        } else {
            res.redirect('/');
        }
    })
})

module.exports = router;