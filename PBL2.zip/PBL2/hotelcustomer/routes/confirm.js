var express = require('express');
var conn = require('./db');
var moment = require('moment');
var router = express.Router();

router.get('/', function(req,res,next){
    var name = req.body.name;
    var phone = req.body.phone;

    var select_sql = `SELECT * FROM reservations WHERE name=? and phone=?;`
    conn.query(select_sql,[name,phone], function(err,rows){
        if(err){
            console.log(err);
        } else {
            console.log(rows);
            res.render('user_information_con', { 'rows':rows, 'moment':moment })
        }
    })
})

router.post('/', function(req, res, next) {
    var name = req.body.name;
    var phone = req.body.phone;

    var select_sql = `SELECT * FROM reservations WHERE name=? and phone=?;`
    conn.query(select_sql,[name,phone], function(err,rows){
        if(err){
            console.log(err);
        } else {
            console.log(rows);
            res.render('user_information_con', { 'rows':rows, 'moment':moment })
        }
    })
});

module.exports = router;