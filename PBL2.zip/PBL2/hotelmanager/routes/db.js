var mysql = require('mysql');

//db connection
var conn = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '123snrnqheK!!',
    database: 'hotel'
});

conn.connect(function (err) {
    if (err) throw err;
    console.log('DB connected!');
});

module.exports = conn;