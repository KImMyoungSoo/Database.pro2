var express = require('express');
var conn = require('./db');
var moment = require('moment')
var router = express.Router();

var req_sql1 = `SELECT * FROM customer_request WHERE check_ok=0;`;
var req_sql2 = `SELECT * FROM customer_request WHERE check_ok=1;`;

/* GET home page. */
router.get('/', function(req, res, next) {
  conn.query(req_sql1, function(err, reqlist1){
    conn.query(req_sql2, function(err2,reqlist2){
      if(err2){
        console.log(err2);
      } else {
        console.log(reqlist2);
        res.render('customer_request', { 'reqlist1':reqlist1, 'reqlist2':reqlist2, 'moment':moment });
      }
    })
    if(err){
      console.log(err);
    } else {
      console.log(reqlist1);
    }
  })
});

//submit
router.post('/', function(req,res,next){

  var id = req.body.check_id;

  var update_sql = `UPDATE customer_request SET check_ok=1 WHERE id=?;`

  conn.query(update_sql,[id], function(err){
    if(err){
      console.log(err);
    } else {
      res.redirect('/customer_request')
    }
  })
});

module.exports = router;