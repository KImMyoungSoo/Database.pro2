var express = require('express');
var conn = require('./db');
var moment = require('moment')

var router = express.Router();

var reserv_sql = `SELECT * FROM reservations;`;
var rooms_sql = `SELECT room_number FROM room WHERE rent=0;`;

/* GET home page. */
router.get('/', function(req, res, next) {
  conn.query(reserv_sql, function(err,result){
    conn.query(rooms_sql, function(err2,roomlist){
      if(err || err2){
        console.log(err);
      } else {
        console.log(result);
        console.log(roomlist);
        res.render('reservation', { 'data1':result, 'data2':roomlist, 'moment':moment });
      }
    })
  })  
});

//submit
router.post('/', function(req,res,next){

  var id = req.body.ID;
  var room_n = req.body.number;
  var staff = req.body.staff;
  
  var id_sql = `SELECT * FROM reservations WHERE id=?;`

  var create_sql = `INSERT INTO rent (room_number, type, checkin, checkout, staff, name, people) VALUES (?,?,?,?,?,?,?);`
  var get_price = `SELECT price_room FROM price WHERE type=?;`
  var create_bill = `INSERT INTO bills (date_bill,total) VALUES (?,?);`

  var delete_reserv = `DELETE FROM reservations WHERE id =?;`

  var update_sql = `UPDATE room SET rent=1 WHERE room_number=?;`

  conn.query(id_sql,[id], function(err, rows){
    if(err){
      console.log(err);
    }
    var res_name = rows[0].name;
    var res_checkin = rows[0].checkin;
    var res_checkout = rows[0].checkout;
    var res_people = rows[0].people;
    var res_type = rows[0].type;

    conn.query(create_sql,[room_n,res_type,res_checkin,res_checkout,staff,res_name,res_people], function(err2){
      conn.query(delete_reserv,[id], function(err3){
        conn.query(update_sql,[room_n], function(err4){
          conn.query(get_price,[res_type], function(err5,pri){
            console.log(pri);
            if(err5){
              console.log(err5);
            }
            var res_price = pri[0].price_room;

            var temp_checkin = res_checkin;
            var temp_checkout = res_checkout;
            var temp_price = 0;

            console.log('temp_checkin:'+temp_checkin.getDate)
            console.log('temp_checkout:'+temp_checkout.getDate)

            while(temp_checkin.getTime() !== temp_checkout.getTime()){
              temp_price = temp_price + res_price;
              temp_checkout.setDate(temp_checkout.getDate()-1);
              console.log('temp_checkin:'+temp_checkin)
              console.log('temp_checkout:'+temp_checkout)
            }

            conn.query(create_bill,[res_checkin,temp_price], function(err6){
              if(err6){
                console.log(err6);
              }
            })
          })
          if(err4){
            console.log(err4);
          }
        })
        if(err3){
          console.log(err3);
        }
      })
      if(err2){
        console.log(err2);
      } else {
        res.redirect('/reservation');
      }
    })
  })
});

module.exports = router;
