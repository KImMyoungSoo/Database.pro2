var express = require('express');
var conn = require('./db');
var router = express.Router();

//delete 
router.post('/', function(req,res,next){
    var del_id = req.body.del_num;
    console.log(del_id);
    var del_sql = `DELETE FROM rent WHERE room_number=?;`
    var update_sql = `UPDATE room SET rent=0 WHERE room_number=?;`
  
    conn.query(del_sql,[del_id], function(err){
      conn.query(update_sql,[del_id], function(err2){
        if(err2){
          console.log(err2);
        }
      })
      if(err){
        console.log(err);
      } else {
        res.redirect('/rent');
      }
    })
  })

module.exports = router;