var express = require('express');
var conn = require('./db');
var moment = require('moment')
var router = express.Router();

var rent_sql = `SELECT * FROM rent;`;
var rooms_sql = `SELECT room_number FROM room WHERE rent=0;`;
/* GET home page. */
router.get('/', function(req, res, next) {
  conn.query(rent_sql, function(err, rents){
    conn.query(rooms_sql, function(err2, roomlist){
      if(err2){
        console.log(err2);
      } else {
        console.log(rents);
        console.log(roomlist);
        res.render('rent', { 'rents' : rents, 'roomlist' : roomlist, 'moment' : moment })
      }
    })
    if(err){
      console.log(err);
    } 
  })
});

//create_rent
router.post('/', function(req,res,next){

  var room_number = req.body.room_number;
  var checkin = req.body.checkin;
  var checkout = req.body.checkout;
  var staff = req.body.staff;
  var name = req.body.name;
  var people = req.body.people;

  var cin = new Date(checkin);
  var cout = new Date(checkout);

  
  console.log(cin);
  console.log(cout);

  var create_sql = `INSERT INTO rent (room_number,type,checkin,checkout,staff,name,people)VALUES (?,?,?,?,?,?,?);`
  var update_sql = `UPDATE room SET rent=1 WHERE room_number=?;`
  var get_type = `SELECT type FROM room WHERE room_number=?;`
  var get_price = `SELECT price_room FROM price WHERE type=?;`
  var create_bill = `INSERT INTO bills (date_bill,total) VALUES (?,?);`

  conn.query(get_type,[room_number], function(err,result){
    if(err){
      console.log(err)
    } else {
      var type = result[0].type;
    }
    conn.query(create_sql,[room_number,type,checkin,checkout,staff,name,people], function(err, rows){
      conn.query(update_sql,[room_number], function(err2){
        if(err2){
          console.log(err2);
        }
        conn.query(get_price,[type], function(err3,pri){
          console.log(pri);
          if(err3){
            console.log(err3);
          }
          var res_price = pri[0].price_room;

          var temp_checkin = cin;
          var temp_checkout = cout;
          var temp_price = 0;

          console.log('temp_checkin:'+temp_checkin.getDate())
          console.log('temp_checkout:'+temp_checkout.getDate())

          while(temp_checkin.getTime() !== temp_checkout.getTime()){
            temp_price = temp_price + res_price;
            temp_checkout.setDate(temp_checkout.getDate()-1);
            console.log('temp_checkin:'+temp_checkin)
            console.log('temp_checkout:'+temp_checkout)
          }
          conn.query(create_bill,[cin,temp_price], function(err6){
            if(err6){
              console.log(err6);
            }
          })
        })
      })
      if(err){
        console.log(err);
      } else {
          res.redirect('/rent');
        }
      })
    })
  });


module.exports = router;