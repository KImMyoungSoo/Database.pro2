var express = require('express');
var conn = require('./db');
var moment = require('moment')

var router = express.Router();

var month_sql = `SELECT SUM(total) as pri FROM bills WHERE (date_bill >= ?) and (date_bill <= ?);`

/* GET home page. */
router.get('/', function(req, res, next) {
  var today = new Date();
  console.log(today);
  var year = today.getFullYear();
  var month = today.getMonth()+1;
  var first = year + "-" + month + "-" + 1;
  var month_first = new Date(first);

  var sday = month_first;
  var lday = today;

  console.log('month '+month_first);
  conn.query(month_sql,[month_first,today], function(err,sprice){
    if(err){
      console.log(err);
    }
    conn.query(month_sql,[sday,lday], function(err,dday){
      if(err){
        console.log(err);
      } else {
        console.log(dday);
        res.render('Money',{ 'sprice':sprice, 'moment':moment, 'month':month_first, 'today':today, 'dday':dday, 'sday':sday, 'lday':lday });
      }
    })
  })
});

//change date
router.post('/', function(req,res,next){
  var Bigin_date = req.body.Bigin_date;
  var Last_date = req.body.Last_date;

  var sday = new Date(Bigin_date);
  var lday = new Date(Last_date);

  var select_sql = `SELECT SUM(total) as pri FROM bills WHERE (date_bill >= ?) and (date_bill <= ?);`

  var today = new Date();
  var year = today.getFullYear();
  var month = today.getMonth()+1;
  var first = year + "-" + month + "-" + 1;
  var month_first = new Date(first);

  conn.query(select_sql,[month_first,today], function(err,sprice){
    if(err){
      console.log(err);
    }
    conn.query(select_sql,[sday,lday], function(err,dday){
      if(err){
        console.log(err);
      } else {
        console.log(dday);
        res.render('Money',{ 'sprice':sprice, 'moment':moment, 'month':month_first, 'today':today, 'dday':dday, 'sday':sday, 'lday':lday });
      }
    })
  })
})


module.exports = router;