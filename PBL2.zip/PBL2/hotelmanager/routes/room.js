var express = require('express');
var conn = require('./db');
var router = express.Router();

var rooms_sql = `SELECT * FROM room;`;

/* GET home page. */
router.get('/', function(req, res, next) {
  conn.query(rooms_sql, function(err, rooms){
    if(err){
      console.log(err);
    } else {
      console.log(rooms);
      res.render('room', { rooms });
    }
  })
});

router.post('/', function(req,res,next){
  var room_num = req.body.room_number;
  var type = req.body.type;

  var create_sql = `INSERT INTO room VALUES(?, ?, 0, 0);`
  var select_sql = `SELECT * FROM room WHERE room_number=?`
  var update_sql = `UPDATE room SET type=? WHERE room_number=?;`

  conn.query(select_sql,[room_num], function(err,roo){
    if(err){
      console.log(err)
    }
    if(roo[0] != undefined){
      conn.query(update_sql,[type,room_num], function(err2){
        if(err2){
          console.log(err2);
        } else {
          res.redirect('room');
        }
      })
    }
    else {
      conn.query(create_sql,[room_num,type],function(err3){
        if(err3){
          console.log(err3);
        }else {
          res.redirect('room');
        }
      })
    }
  })
})

//modift
router.post('/', function(req,res,next){
  var name = req.body.name;
  var phone = req.body.phone;
  var department = req.body.department;

  var select_sql = `SELECT * FROM employee WHERE name=?`
  var create_sql = `INSERT INTO employee (name,phone,department) VALUES(?,?,?);`
  var update_sql = `UPDATE employee SET phone=?, department=? WHERE name=?;`
  conn.query(select_sql,[name], function(err, rows){
    if(err){
      console.log(err);
    }else{
      console.log(rows);
    }
    if(rows[0] != undefined){
      conn.query(update_sql,[phone,department,name], function(err2){
        if(err2){
          console.log(err2);
        } else {
          res.redirect('/employee_manage/service');
        }
      })
    }
    else {
      conn.query(create_sql,[name,phone,department],function(err3){
        if(err3){
          console.log(err3);
        }else {
          res.redirect('/employee_manage/service');
        }
      })
    }
  })
})


module.exports = router;