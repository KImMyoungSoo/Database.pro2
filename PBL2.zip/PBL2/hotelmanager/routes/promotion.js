var express = require('express');
var conn = require('./db');

var router = express.Router();

var emp_sql = `SELECT * FROM employee WHERE department='promotion';`;

/* GET home page. */
router.get('/', function(req, res, next) {
  conn.query(emp_sql, function(err,results){
    if(err){
      console.log(err)
    } else {
      console.log(results);
      res.render('./employee_manage/promotion',{ results });  
    }
  })
});

//modift
router.post('/', function(req,res,next){
  var name = req.body.name;
  var phone = req.body.phone;
  var department = req.body.department;

  var select_sql = `SELECT * FROM employee WHERE name=?`
  var create_sql = `INSERT INTO employee (name,phone,department) VALUES(?,?,?);`
  var update_sql = `UPDATE employee SET phone=?, department=? WHERE name=?;`
  conn.query(select_sql,[name], function(err, rows){
    if(err){
      console.log(err);
    }else{
      console.log(rows);
    }
    if(rows[0] != undefined){
      conn.query(update_sql,[phone,department,name], function(err2){
        if(err2){
          console.log(err2);
        } else {
          res.redirect('/employee_manage/promotion');
        }
      })
    }
    else {
      conn.query(create_sql,[name,phone,department],function(err3){
        if(err3){
          console.log(err3);
        }else {
          res.redirect('/employee_manage/promotion');
        }
      })
    }
  })
})

module.exports = router;