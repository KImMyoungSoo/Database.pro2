var express = require('express');
var conn = require('./db');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index');
});

module.exports = router;


router.post('/',function(req,res){
  var uid = req.body.uid;
  var upwd = req.body.upwd;
  var sql = 'select * from manager where id=? and password=?'
  conn.query(sql,[uid,upwd],function(err,rows,fields){
    if(err){
      console.log(err);
      res.status(500).send('Internal Server Error');
    }
    else{
      if(rows[0] != undefined){
        res.redirect('/rent');
      }
      else{
        res.write("<script language=\"javascript\">alert('try again')</script>");
        res.write("<script language=\"javascript\">window.location=\"\"</script>");
      }
    }
  })
})