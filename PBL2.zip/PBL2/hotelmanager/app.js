var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var mysql = require('mysql');
var bodyParser = require('body-parser');

var indexRouter = require('./routes/index');
var rentRouter = require('./routes/rent');
var roomRouter = require('./routes/room');
var usersRouter = require('./routes/users');
var moneyRouter = require('./routes/money');
var manage_EmpRouter = require('./routes/manage_Emp');
var reservRouter = require('./routes/reservation');
var customerRouter = require('./routes/customer_request');
var securityRouter = require('./routes/security');
var promotionRouter = require('./routes/promotion');
var facilityRouter = require('./routes/facility');
var accountingRouter = require('./routes/accounting');
var inforRouter = require('./routes/user_information');
var deleteRouter = require('./routes/delete');
var serviceRouter = require('./routes/service');
var humanRouter = require('./routes/human_resource');
var deletecustomRouter = require('./routes/deletecustom');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/rent', rentRouter);
app.use('/users', usersRouter);
app.use('/room', roomRouter);
app.use('/Money', moneyRouter);
app.use('/manage_Emp', manage_EmpRouter);
app.use('/reservation', reservRouter);
app.use('/customer_request', customerRouter);
app.use('/employee_manage/security', securityRouter);
app.use('/employee_manage/promotion', promotionRouter);
app.use('/employee_manage/facility', facilityRouter);
app.use('/employee_manage/accounting', accountingRouter);
app.use('/user_information', inforRouter);
app.use('/delete', deleteRouter);
app.use('/employee_manage/service', serviceRouter);
app.use('/employee_manage/human_resource', humanRouter);
app.use('/deletecustom',deletecustomRouter);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});


// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
